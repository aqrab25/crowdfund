import { pgTable, text, serial, integer, boolean, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const campaigns = pgTable("campaigns", {
  id: serial("id").primaryKey(),
  contractAddress: text("contract_address").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  goalAmount: decimal("goal_amount", { precision: 18, scale: 8 }).notNull(),
  currentAmount: decimal("current_amount", { precision: 18, scale: 8 }).default("0"),
  creatorAddress: text("creator_address").notNull(),
  imageUrl: text("image_url").notNull(),
  endDate: timestamp("end_date").notNull(),
  isActive: boolean("is_active").default(true),
  category: text("category").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const fundings = pgTable("fundings", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").references(() => campaigns.id).notNull(),
  funderAddress: text("funder_address").notNull(),
  amount: decimal("amount", { precision: 18, scale: 8 }).notNull(),
  transactionHash: text("transaction_hash").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCampaignSchema = z.object({
  title: z.string().min(1),
  description: z.string().min(1),
  goalAmount: z.string(),
  endDate: z.date(),
  category: z.string().min(1),
  contractAddress: z.string().min(1),
  creatorAddress: z.string().min(1),
  imageUrl: z.string().min(1),
});

export const insertFundingSchema = createInsertSchema(fundings).omit({
  id: true,
  createdAt: true,
});

export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type Funding = typeof fundings.$inferSelect;
export type InsertFunding = z.infer<typeof insertFundingSchema>;
