import { ethers } from "hardhat";

async function main() {
  console.log("Starting deployment...");

  // Get the contract factory
  const Crowdfunding = await ethers.getContractFactory("Crowdfunding");

  // Deploy the contract
  console.log("Deploying Crowdfunding contract...");
  const crowdfunding = await Crowdfunding.deploy();

  // Wait for deployment to complete
  await crowdfunding.waitForDeployment();

  const contractAddress = await crowdfunding.getAddress();
  console.log("Crowdfunding contract deployed to:", contractAddress);

  // Verify the deployment
  console.log("Verifying deployment...");
  const deploymentTx = crowdfunding.deploymentTransaction();
  if (deploymentTx) {
    console.log("Deployment transaction hash:", deploymentTx.hash);
    console.log("Waiting for confirmation...");
    await deploymentTx.wait(1);
    console.log("Deployment confirmed!");
  }

  // Display contract information
  console.log("\n=== Deployment Summary ===");
  console.log("Contract Name: Crowdfunding");
  console.log("Contract Address:", contractAddress);
  console.log("Network:", await ethers.provider.getNetwork());
  console.log("Deployer:", await crowdfunding.owner());

  // Save deployment info to file
  import fs from "fs";
  import path from "path";

  const deploymentInfo = {
    contractName: "Crowdfunding",
    contractAddress: contractAddress,
    deploymentBlock: deploymentTx ? deploymentTx.blockNumber : "unknown",
    deploymentTx: deploymentTx ? deploymentTx.hash : "unknown",
    deployer: await crowdfunding.owner(),
    deployedAt: new Date().toISOString(),
    network: await ethers.provider.getNetwork()
  };

  const deploymentPath = path.join(__dirname, "..", "deployment.json");
  fs.writeFileSync(deploymentPath, JSON.stringify(deploymentInfo, null, 2));
  console.log("Deployment info saved to:", deploymentPath);

  return contractAddress;
}

// Handle deployment errors
main()
  .then((contractAddress) => {
    console.log("\n✅ Deployment completed successfully!");
    console.log("Contract address:", contractAddress);
    process.exit(0);
  })
  .catch((error) => {
    console.error("\n❌ Deployment failed:");
    console.error(error);
    process.exit(1);
  });
