import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import WalletConnect from "@/components/wallet-connect";
import CampaignCard from "@/components/campaign-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Rocket, Search, Lightbulb, Heart, Users, Coins, TrendingUp } from "lucide-react";
import type { Campaign } from "@shared/schema";

export default function Home() {
  const { data: campaigns = [], isLoading } = useQuery<Campaign[]>({
    queryKey: ["/api/campaigns"],
  });

  const featuredCampaigns = campaigns.slice(0, 3);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-8">
              <h1 className="text-2xl font-bold text-primary-custom">CryptoFund</h1>
              <div className="hidden md:flex items-center space-x-8">
                <Link href="/campaigns" className="text-gray-700 hover:text-primary-custom font-medium">
                  Explore
                </Link>
                <Link href="/campaigns" className="text-gray-700 hover:text-primary-custom font-medium">
                  Start Campaign
                </Link>
                <a href="#how-it-works" className="text-gray-700 hover:text-primary-custom font-medium">
                  How it Works
                </a>
              </div>
            </div>
            <WalletConnect />
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="gradient-primary text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl font-bold mb-6 leading-tight">
                Fund Innovation on the{" "}
                <span className="text-yellow-300">Blockchain</span>
              </h1>
              <p className="text-xl mb-8 text-blue-100 leading-relaxed">
                Create and back groundbreaking projects with transparent, decentralized crowdfunding powered by Polygon.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/campaigns">
                  <Button className="bg-accent-custom hover:bg-accent-custom/90 text-dark-custom px-8 py-4 h-auto text-lg font-semibold">
                    <Rocket className="mr-2 h-5 w-5" />
                    Start Your Campaign
                  </Button>
                </Link>
                <Link href="/campaigns">
                  <Button variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-primary-custom px-8 py-4 h-auto text-lg font-semibold">
                    <Search className="mr-2 h-5 w-5" />
                    Explore Projects
                  </Button>
                </Link>
              </div>
            </div>
            <div className="hidden lg:block">
              <div className="bg-white bg-opacity-10 rounded-2xl p-8 backdrop-blur-sm">
                <div className="grid grid-cols-3 gap-4">
                  <Card className="bg-secondary-custom text-white border-0">
                    <CardContent className="p-4 text-center">
                      <Coins className="mx-auto mb-2 h-6 w-6" />
                      <div className="text-sm">Total Raised</div>
                      <div className="font-bold">$2.5M</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-accent-custom text-dark-custom border-0">
                    <CardContent className="p-4 text-center">
                      <TrendingUp className="mx-auto mb-2 h-6 w-6" />
                      <div className="text-sm">Active Projects</div>
                      <div className="font-bold">156</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-purple-500 text-white border-0">
                    <CardContent className="p-4 text-center">
                      <Users className="mx-auto mb-2 h-6 w-6" />
                      <div className="text-sm">Backers</div>
                      <div className="font-bold">12.8K</div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Campaigns */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-dark-custom mb-4">Featured Campaigns</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Discover innovative projects that are changing the world through blockchain technology.
            </p>
          </div>

          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-gray-200 rounded-xl h-96 animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredCampaigns.map((campaign) => (
                <CampaignCard key={campaign.id} campaign={campaign} />
              ))}
            </div>
          )}

          <div className="text-center mt-12">
            <Link href="/campaigns">
              <Button className="bg-gray-800 hover:bg-gray-700 text-white px-8 py-3 h-auto text-lg font-medium">
                View All Campaigns
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Create Campaign CTA */}
      <section className="py-16 gradient-primary">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-white mb-6">Ready to Launch Your Project?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Turn your innovative ideas into reality with transparent, blockchain-powered crowdfunding. 
            No intermediaries, just direct support from the community.
          </p>
          <Link href="/campaigns">
            <Button className="bg-accent-custom hover:bg-accent-custom/90 text-dark-custom px-8 py-4 h-auto text-lg font-semibold">
              <Rocket className="mr-2 h-5 w-5" />
              Create Campaign
            </Button>
          </Link>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-dark-custom mb-4">How It Works</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Simple, transparent, and secure crowdfunding powered by blockchain technology.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-primary-custom w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Lightbulb className="text-white h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold text-dark-custom mb-4">1. Create Campaign</h3>
              <p className="text-gray-600">Set up your project with goals, timeline, and rewards. Upload to IPFS for permanent storage.</p>
            </div>

            <div className="text-center">
              <div className="bg-secondary-custom w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Heart className="text-white h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold text-dark-custom mb-4">2. Get Funded</h3>
              <p className="text-gray-600">Supporters back your project directly through smart contracts. All transactions are transparent.</p>
            </div>

            <div className="text-center">
              <div className="bg-accent-custom w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Rocket className="text-white h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold text-dark-custom mb-4">3. Launch Project</h3>
              <p className="text-gray-600">Once funded, access your funds and bring your innovative project to life!</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-dark-custom text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <h3 className="text-2xl font-bold mb-4">CryptoFund</h3>
              <p className="text-gray-300 mb-6 max-w-md">
                The future of crowdfunding is here. Transparent, decentralized, and powered by blockchain technology.
              </p>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-gray-300">
                <li><Link href="/campaigns" className="hover:text-white">Explore Campaigns</Link></li>
                <li><Link href="/campaigns" className="hover:text-white">Create Campaign</Link></li>
                <li><a href="#how-it-works" className="hover:text-white">How it Works</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-300">
                <li><a href="#" className="hover:text-white">Help Center</a></li>
                <li><a href="#" className="hover:text-white">Documentation</a></li>
                <li><a href="#" className="hover:text-white">Contact Us</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400">© 2024 CryptoFund. All rights reserved.</p>
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <span className="text-gray-400 text-sm">Powered by</span>
              <span className="text-purple-400 font-medium">Polygon</span>
              <span className="text-orange-400 font-medium">IPFS</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
