import { useQuery } from "@tanstack/react-query";
import { Link, useParams } from "wouter";
import WalletConnect from "@/components/wallet-connect";
import FundingModal from "@/components/funding-modal";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Users, Calendar, Target } from "lucide-react";
import type { Campaign, Funding } from "@shared/schema";

export default function CampaignDetails() {
  const { id } = useParams();
  const campaignId = parseInt(id || "0");

  const { data: campaign, isLoading: campaignLoading } = useQuery<Campaign>({
    queryKey: [`/api/campaigns/${campaignId}`],
  });

  const { data: fundings = [], isLoading: fundingsLoading } = useQuery<Funding[]>({
    queryKey: [`/api/campaigns/${campaignId}/fundings`],
  });

  if (campaignLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Campaign not found</h2>
          <Link href="/campaigns">
            <Button>Back to Campaigns</Button>
          </Link>
        </div>
      </div>
    );
  }

  const progress = (parseFloat(campaign.currentAmount) / parseFloat(campaign.goalAmount)) * 100;
  const remaining = parseFloat(campaign.goalAmount) - parseFloat(campaign.currentAmount);
  const endDate = new Date(campaign.endDate);
  const isExpired = endDate < new Date();
  const daysLeft = Math.max(0, Math.ceil((endDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)));

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-8">
              <Link href="/">
                <h1 className="text-2xl font-bold text-primary-custom cursor-pointer">CryptoFund</h1>
              </Link>
              <div className="hidden md:flex items-center space-x-8">
                <Link href="/campaigns" className="text-gray-700 hover:text-primary-custom font-medium">
                  Explore
                </Link>
              </div>
            </div>
            <WalletConnect />
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <Link href="/campaigns">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Campaigns
          </Button>
        </Link>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Campaign Image */}
            <div className="aspect-video mb-6 rounded-xl overflow-hidden">
              <img 
                src={campaign.imageUrl} 
                alt={campaign.title}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Campaign Info */}
            <div className="bg-white rounded-xl p-6 mb-6">
              <div className="flex items-center gap-3 mb-4">
                <Badge className="bg-secondary-custom text-white">
                  {campaign.category}
                </Badge>
                {isExpired && (
                  <Badge variant="destructive">Expired</Badge>
                )}
                {!isExpired && progress >= 100 && (
                  <Badge className="bg-green-500 text-white">Funded</Badge>
                )}
              </div>

              <h1 className="text-3xl font-bold text-dark-custom mb-4">
                {campaign.title}
              </h1>

              <p className="text-gray-600 text-lg leading-relaxed mb-6">
                {campaign.description}
              </p>

              <div className="grid sm:grid-cols-3 gap-4 text-center">
                <div className="flex items-center justify-center gap-2">
                  <Target className="h-5 w-5 text-gray-400" />
                  <div>
                    <div className="text-sm text-gray-500">Goal</div>
                    <div className="font-semibold">{campaign.goalAmount} MATIC</div>
                  </div>
                </div>
                <div className="flex items-center justify-center gap-2">
                  <Users className="h-5 w-5 text-gray-400" />
                  <div>
                    <div className="text-sm text-gray-500">Backers</div>
                    <div className="font-semibold">{fundings.length}</div>
                  </div>
                </div>
                <div className="flex items-center justify-center gap-2">
                  <Calendar className="h-5 w-5 text-gray-400" />
                  <div>
                    <div className="text-sm text-gray-500">Days Left</div>
                    <div className="font-semibold">{isExpired ? 0 : daysLeft}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Funders */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4">Recent Backers</h3>
                {fundingsLoading ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="h-12 bg-gray-200 rounded animate-pulse" />
                    ))}
                  </div>
                ) : fundings.length > 0 ? (
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {fundings.map((funding) => (
                      <div key={funding.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <span className="font-mono text-sm text-gray-600">
                          {funding.funderAddress.substring(0, 6)}...{funding.funderAddress.substring(38)}
                        </span>
                        <span className="font-semibold text-secondary-custom">
                          {funding.amount} MATIC
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 text-center py-8">No backers yet. Be the first!</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Funding Progress */}
            <Card>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>{campaign.currentAmount} MATIC</span>
                    <span>{campaign.goalAmount} MATIC</span>
                  </div>
                  <Progress value={Math.min(progress, 100)} className="h-3" />
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">{Math.round(progress)}% funded</span>
                    <span className="text-gray-500">
                      {isExpired ? "Campaign ended" : `${daysLeft} days left`}
                    </span>
                  </div>
                </div>

                <div className="mt-6 space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Raised:</span>
                    <span className="font-semibold">{campaign.currentAmount} MATIC</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Remaining:</span>
                    <span className="font-semibold">{remaining.toFixed(4)} MATIC</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">End Date:</span>
                    <span className="font-semibold">{endDate.toLocaleDateString()}</span>
                  </div>
                </div>

                {!isExpired && progress < 100 && (
                  <FundingModal campaignId={campaign.id} className="w-full mt-6" />
                )}

                {isExpired && (
                  <Button disabled className="w-full mt-6">
                    Campaign Ended
                  </Button>
                )}

                {progress >= 100 && (
                  <Button disabled className="w-full mt-6 bg-green-500">
                    Fully Funded!
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Creator Info */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-3">Creator</h3>
                <div className="space-y-2">
                  <div className="font-mono text-sm text-gray-600 break-all">
                    {campaign.creatorAddress}
                  </div>
                  <div className="text-sm text-gray-500">
                    Created on {new Date(campaign.createdAt!).toLocaleDateString()}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
