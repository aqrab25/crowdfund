import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Users, Calendar } from "lucide-react";
import type { Campaign } from "@shared/schema";

interface CampaignCardProps {
  campaign: Campaign;
}

export default function CampaignCard({ campaign }: CampaignCardProps) {
  const progress = (parseFloat(campaign.currentAmount) / parseFloat(campaign.goalAmount)) * 100;
  const endDate = new Date(campaign.endDate);
  const isExpired = endDate < new Date();
  const daysLeft = Math.max(0, Math.ceil((endDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)));

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      Technology: "bg-secondary-custom",
      Education: "bg-purple-500",
      Agriculture: "bg-secondary-custom",
      Health: "bg-blue-500",
      Environment: "bg-green-500",
      Art: "bg-pink-500",
    };
    return colors[category] || "bg-gray-500";
  };

  return (
    <Card className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden border border-gray-200">
      <div className="aspect-video overflow-hidden">
        <img 
          src={campaign.imageUrl} 
          alt={campaign.title}
          className="w-full h-full object-cover"
        />
      </div>
      
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-3">
          <Badge className={`${getCategoryColor(campaign.category)} text-white`}>
            {campaign.category}
          </Badge>
          <span className="text-sm text-gray-500">
            {isExpired ? "Ended" : `${daysLeft} days left`}
          </span>
        </div>
        
        <h3 className="text-xl font-semibold text-dark-custom mb-2 line-clamp-2">
          {campaign.title}
        </h3>
        <p className="text-gray-600 mb-4 line-clamp-3">
          {campaign.description}
        </p>
        
        <div className="mb-4">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>{campaign.currentAmount} MATIC</span>
            <span>{campaign.goalAmount} MATIC</span>
          </div>
          <Progress value={Math.min(progress, 100)} className="h-3" />
          <div className="text-right text-sm text-gray-500 mt-1">
            {Math.round(progress)}% funded
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 text-sm text-gray-600">
            <div className="flex items-center space-x-1">
              <Users className="h-4 w-4" />
              <span>0 backers</span>
            </div>
            <div className="flex items-center space-x-1">
              <Calendar className="h-4 w-4" />
              <span>{endDate.toLocaleDateString()}</span>
            </div>
          </div>
          <Link href={`/campaign/${campaign.id}`}>
            <Button className="bg-primary-custom hover:bg-primary-custom/90 text-white">
              View Details
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
