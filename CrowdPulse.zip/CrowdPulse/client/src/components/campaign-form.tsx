import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, AlertCircle } from "lucide-react";

const campaignSchema = z.object({
  title: z.string().min(1, "Title is required").max(100, "Title must be less than 100 characters"),
  description: z.string().min(1, "Description is required").max(1000, "Description must be less than 1000 characters"),
  goalAmount: z.string().min(1, "Goal amount is required").refine((val) => parseFloat(val) > 0, "Goal amount must be greater than 0"),
  endDate: z.string().min(1, "End date is required").refine((val) => new Date(val) > new Date(), "End date must be in the future"),
  category: z.string().min(1, "Category is required"),
});

type CampaignFormData = z.infer<typeof campaignSchema>;

const categories = ["Technology", "Education", "Agriculture", "Health", "Environment", "Art"];

interface CampaignFormProps {
  onSuccess: () => void;
}

export default function CampaignForm({ onSuccess }: CampaignFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<CampaignFormData>({
    resolver: zodResolver(campaignSchema),
    defaultValues: {
      title: "",
      description: "",
      goalAmount: "",
      endDate: "",
      category: "",
    },
  });

  const createCampaignMutation = useMutation({
    mutationFn: async (data: any) => {
      console.log("Sending data to API:", data);
      return apiRequest("POST", "/api/campaigns", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({
        title: "Campaign Created",
        description: "Your campaign has been successfully created!",
      });
      onSuccess();
    },
    onError: (error: any) => {
      console.error("Campaign creation error:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to create campaign. Please try again.",
        variant: "destructive",
      });
    },
  });



  const onSubmit = async (data: CampaignFormData) => {
    console.log("Form submission started with data:", data);
    
    // Check if wallet is connected
    if (!window.ethereum) {
      toast({
        title: "Wallet Required",
        description: "Please connect your MetaMask wallet to create a campaign",
        variant: "destructive",
      });
      return;
    }

    try {
      // Get current account
      const accounts = await window.ethereum.request({ method: 'eth_accounts' });
      if (accounts.length === 0) {
        toast({
          title: "Wallet Not Connected",
          description: "Please connect your wallet first",
          variant: "destructive",
        });
        return;
      }

      // Generate contract address for demo
      const contractAddress = "0x" + Math.random().toString(16).substr(2, 40);
      
      const campaignData = {
        title: data.title,
        description: data.description,
        goalAmount: data.goalAmount,
        endDate: new Date(data.endDate).toISOString(),
        category: data.category,
        creatorAddress: accounts[0],
        contractAddress: contractAddress,
        imageUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&h=600&fit=crop",
      };

      console.log("Submitting campaign data:", campaignData);
      await createCampaignMutation.mutateAsync(campaignData);
    } catch (error) {
      console.error("Campaign creation error:", error);
      toast({
        title: "Error",
        description: "Failed to create campaign. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Campaign Name</FormLabel>
              <FormControl>
                <Input placeholder="Enter your campaign name" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Describe your project in detail..." 
                  rows={4}
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="goalAmount"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Funding Goal (MATIC)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    step="0.01" 
                    min="0" 
                    placeholder="0.00" 
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="endDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>End Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="category"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Category</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />



        <Card className="bg-yellow-50 border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium text-yellow-800">Platform Fee</h4>
                <p className="text-sm text-yellow-700">
                  If you end your campaign early, a 5% platform fee will be deducted from the raised funds.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex space-x-4 pt-4">
          <Button 
            type="button" 
            variant="outline" 
            className="flex-1"
            onClick={onSuccess}
          >
            Cancel
          </Button>
          <Button 
            type="submit" 
            className="flex-1 bg-primary-custom hover:bg-primary-custom/90 text-white"
            disabled={createCampaignMutation.isPending}
          >
            {createCampaignMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Creating...
              </>
            ) : (
              "Launch Campaign"
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
}
