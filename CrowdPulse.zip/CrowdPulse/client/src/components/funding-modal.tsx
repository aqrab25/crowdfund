import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Loader2 } from "lucide-react";

const fundingSchema = z.object({
  amount: z.string().min(1, "Amount is required").refine((val) => parseFloat(val) > 0, "Amount must be greater than 0"),
});

type FundingFormData = z.infer<typeof fundingSchema>;

interface FundingModalProps {
  campaignId: number;
  className?: string;
}

export default function FundingModal({ campaignId, className = "" }: FundingModalProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FundingFormData>({
    resolver: zodResolver(fundingSchema),
    defaultValues: {
      amount: "",
    },
  });

  const fundCampaignMutation = useMutation({
    mutationFn: async (data: { amount: string; funderAddress: string; transactionHash: string }) => {
      return apiRequest("POST", `/api/campaigns/${campaignId}/fund`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/campaigns/${campaignId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/campaigns/${campaignId}/fundings`] });
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      
      toast({
        title: "Funding Successful",
        description: "Your contribution has been recorded successfully!",
      });
      
      setIsOpen(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Funding Failed",
        description: "Failed to process your contribution. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: FundingFormData) => {
    // Check if wallet is connected
    if (!window.ethereum) {
      toast({
        title: "Wallet Required",
        description: "Please connect your MetaMask wallet to fund this campaign",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);

    try {
      // Get current account
      const accounts = await window.ethereum.request({ method: 'eth_accounts' });
      if (accounts.length === 0) {
        toast({
          title: "Wallet Not Connected",
          description: "Please connect your wallet first",
          variant: "destructive",
        });
        setIsProcessing(false);
        return;
      }

      // Simulate blockchain transaction
      const mockTxHash = "0x" + Math.random().toString(16).substr(2, 64);
      
      // In a real implementation, this would interact with the smart contract
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate transaction time

      const fundingData = {
        amount: data.amount,
        funderAddress: accounts[0],
        transactionHash: mockTxHash,
      };

      fundCampaignMutation.mutate(fundingData);
    } catch (error: any) {
      console.error('Error processing funding:', error);
      toast({
        title: "Transaction Failed",
        description: error.message || "Failed to process transaction",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className={`bg-primary-custom hover:bg-primary-custom/90 text-white ${className}`}>
          Fund Campaign
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Fund This Campaign</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount (MATIC)</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      step="0.01" 
                      min="0.01" 
                      placeholder="Enter amount in MATIC"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0">
                  <div className="h-5 w-5 bg-blue-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs font-bold">i</span>
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-blue-800">Transaction Info</h4>
                  <p className="text-sm text-blue-700">
                    Your contribution will be sent directly to the campaign smart contract. 
                    All transactions are transparent and recorded on the blockchain.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex space-x-4">
              <Button 
                type="button" 
                variant="outline" 
                className="flex-1"
                onClick={() => setIsOpen(false)}
                disabled={isProcessing || fundCampaignMutation.isPending}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="flex-1 bg-primary-custom hover:bg-primary-custom/90 text-white"
                disabled={isProcessing || fundCampaignMutation.isPending}
              >
                {isProcessing || fundCampaignMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {isProcessing ? "Processing..." : "Recording..."}
                  </>
                ) : (
                  "Fund Campaign"
                )}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
