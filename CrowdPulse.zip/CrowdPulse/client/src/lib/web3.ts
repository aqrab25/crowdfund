import { ethers } from "ethers";

// Smart contract ABI (simplified for crowdfunding)
export const CROWDFUNDING_ABI = [
  "function createCampaign(string memory _title, string memory _description, uint256 _goal, uint256 _endTime, string memory _imageHash) public returns (uint256)",
  "function fundCampaign(uint256 _campaignId) public payable",
  "function withdrawFunds(uint256 _campaignId) public",
  "function endCampaignEarly(uint256 _campaignId) public",
  "function getCampaign(uint256 _campaignId) public view returns (tuple(string title, string description, uint256 goal, uint256 raised, uint256 endTime, address creator, bool active, string imageHash))",
  "function getFunders(uint256 _campaignId) public view returns (address[], uint256[])",
  "event CampaignCreated(uint256 indexed campaignId, address indexed creator, uint256 goal)",
  "event CampaignFunded(uint256 indexed campaignId, address indexed funder, uint256 amount)",
  "event CampaignEnded(uint256 indexed campaignId, bool successful)"
];

export class Web3Service {
  private provider: ethers.BrowserProvider | null = null;
  private signer: ethers.Signer | null = null;
  private contract: ethers.Contract | null = null;

  constructor() {
    if (typeof window !== "undefined" && window.ethereum) {
      this.provider = new ethers.BrowserProvider(window.ethereum);
    }
  }

  async connectWallet(): Promise<string> {
    if (!this.provider) {
      throw new Error("MetaMask not installed");
    }

    const accounts = await this.provider.send("eth_requestAccounts", []);
    this.signer = await this.provider.getSigner();
    
    return accounts[0];
  }

  async getNetwork(): Promise<ethers.Network> {
    if (!this.provider) {
      throw new Error("Provider not initialized");
    }

    return await this.provider.getNetwork();
  }

  async switchToPolygon(): Promise<void> {
    if (!window.ethereum) {
      throw new Error("MetaMask not installed");
    }

    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: '0x89' }], // Polygon Mainnet
      });
    } catch (switchError: any) {
      // Chain not added to MetaMask
      if (switchError.code === 4902) {
        await window.ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [{
            chainId: '0x89',
            chainName: 'Polygon Mainnet',
            nativeCurrency: {
              name: 'MATIC',
              symbol: 'MATIC',
              decimals: 18,
            },
            rpcUrls: ['https://polygon-rpc.com/'],
            blockExplorerUrls: ['https://polygonscan.com/'],
          }],
        });
      } else {
        throw switchError;
      }
    }
  }

  initContract(contractAddress: string): void {
    if (!this.signer) {
      throw new Error("Wallet not connected");
    }

    this.contract = new ethers.Contract(contractAddress, CROWDFUNDING_ABI, this.signer);
  }

  async createCampaign(
    title: string,
    description: string,
    goalInMatic: string,
    endDate: Date,
    imageHash: string
  ): Promise<string> {
    if (!this.contract) {
      throw new Error("Contract not initialized");
    }

    const goalWei = ethers.parseEther(goalInMatic);
    const endTime = Math.floor(endDate.getTime() / 1000);

    const tx = await this.contract.createCampaign(title, description, goalWei, endTime, imageHash);
    await tx.wait();

    return tx.hash;
  }

  async fundCampaign(campaignId: number, amountInMatic: string): Promise<string> {
    if (!this.contract) {
      throw new Error("Contract not initialized");
    }

    const amountWei = ethers.parseEther(amountInMatic);
    const tx = await this.contract.fundCampaign(campaignId, { value: amountWei });
    await tx.wait();

    return tx.hash;
  }

  async getCampaignDetails(campaignId: number): Promise<any> {
    if (!this.contract) {
      throw new Error("Contract not initialized");
    }

    return await this.contract.getCampaign(campaignId);
  }

  async getFunders(campaignId: number): Promise<{ addresses: string[], amounts: string[] }> {
    if (!this.contract) {
      throw new Error("Contract not initialized");
    }

    const [addresses, amounts] = await this.contract.getFunders(campaignId);
    return { 
      addresses, 
      amounts: amounts.map((amount: bigint) => ethers.formatEther(amount)) 
    };
  }

  async withdrawFunds(campaignId: number): Promise<string> {
    if (!this.contract) {
      throw new Error("Contract not initialized");
    }

    const tx = await this.contract.withdrawFunds(campaignId);
    await tx.wait();

    return tx.hash;
  }

  async endCampaignEarly(campaignId: number): Promise<string> {
    if (!this.contract) {
      throw new Error("Contract not initialized");
    }

    const tx = await this.contract.endCampaignEarly(campaignId);
    await tx.wait();

    return tx.hash;
  }

  formatEther(wei: bigint): string {
    return ethers.formatEther(wei);
  }

  parseEther(ether: string): bigint {
    return ethers.parseEther(ether);
  }
}

export const web3Service = new Web3Service();
