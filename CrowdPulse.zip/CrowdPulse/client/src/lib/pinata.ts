// Pinata IPFS integration for storing campaign images
export class PinataService {
  private apiKey: string;
  private apiSecret: string;
  private baseUrl = "https://api.pinata.cloud";

  constructor() {
    this.apiKey = import.meta.env.VITE_PINATA_API_KEY || "";
    this.apiSecret = import.meta.env.VITE_PINATA_API_SECRET || "";
    
    if (!this.apiKey || !this.apiSecret) {
      console.warn("Pinata API credentials not found. Image uploads will not work.");
    }
  }

  async uploadFile(file: File): Promise<{ ipfsHash: string; ipfsUrl: string }> {
    if (!this.apiKey || !this.apiSecret) {
      throw new Error("Pinata API credentials not configured. Please check your environment variables.");
    }

    const formData = new FormData();
    formData.append("file", file);

    const metadata = JSON.stringify({
      name: `campaign-image-${Date.now()}`,
      keyvalues: {
        timestamp: new Date().toISOString(),
        type: "campaign-image"
      }
    });
    formData.append("pinataMetadata", metadata);

    const options = JSON.stringify({
      cidVersion: 0,
    });
    formData.append("pinataOptions", options);

    try {
      console.log("Uploading to Pinata...", { 
        hasApiKey: !!this.apiKey, 
        hasApiSecret: !!this.apiSecret,
        fileSize: file.size,
        fileName: file.name 
      });

      const response = await fetch(`${this.baseUrl}/pinning/pinFileToIPFS`, {
        method: "POST",
        headers: {
          "pinata_api_key": this.apiKey,
          "pinata_secret_api_key": this.apiSecret,
        },
        body: formData,
      });

      const responseText = await response.text();
      console.log("Pinata response:", { status: response.status, response: responseText });

      if (!response.ok) {
        throw new Error(`Pinata upload failed (${response.status}): ${responseText}`);
      }

      const result = JSON.parse(responseText);
      const ipfsHash = result.IpfsHash;
      const ipfsUrl = `https://gateway.pinata.cloud/ipfs/${ipfsHash}`;

      return { ipfsHash, ipfsUrl };
    } catch (error: any) {
      console.error("Pinata upload error:", error);
      if (error.message.includes("401") || error.message.includes("403")) {
        throw new Error("Invalid Pinata API credentials. Please check your API key and secret.");
      }
      throw new Error(`Failed to upload file to IPFS: ${error.message}`);
    }
  }

  async uploadJSON(jsonObject: any): Promise<{ ipfsHash: string; ipfsUrl: string }> {
    if (!this.apiKey || !this.apiSecret) {
      throw new Error("Pinata API credentials not configured");
    }

    const data = {
      pinataContent: jsonObject,
      pinataMetadata: {
        name: `campaign-metadata-${Date.now()}`,
        keyvalues: {
          timestamp: new Date().toISOString(),
          type: "campaign-metadata"
        }
      }
    };

    try {
      const response = await fetch(`${this.baseUrl}/pinning/pinJSONToIPFS`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "pinata_api_key": this.apiKey,
          "pinata_secret_api_key": this.apiSecret,
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error(`Pinata upload failed: ${response.statusText}`);
      }

      const result = await response.json();
      const ipfsHash = result.IpfsHash;
      const ipfsUrl = `https://gateway.pinata.cloud/ipfs/${ipfsHash}`;

      return { ipfsHash, ipfsUrl };
    } catch (error) {
      console.error("Pinata JSON upload error:", error);
      throw new Error("Failed to upload JSON to IPFS");
    }
  }

  getIPFSUrl(hash: string): string {
    return `https://gateway.pinata.cloud/ipfs/${hash}`;
  }

  async testAuthentication(): Promise<boolean> {
    if (!this.apiKey || !this.apiSecret) {
      return false;
    }

    try {
      const response = await fetch(`${this.baseUrl}/data/testAuthentication`, {
        method: "GET",
        headers: {
          "pinata_api_key": this.apiKey,
          "pinata_secret_api_key": this.apiSecret,
        },
      });

      return response.ok;
    } catch (error) {
      console.error("Pinata authentication test failed:", error);
      return false;
    }
  }
}

export const pinataService = new PinataService();
