import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCampaignSchema, insertFundingSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all campaigns
  app.get("/api/campaigns", async (req, res) => {
    try {
      const campaigns = await storage.getCampaigns();
      res.json(campaigns);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch campaigns" });
    }
  });

  // Get campaign by ID
  app.get("/api/campaigns/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const campaign = await storage.getCampaignById(id);
      
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      res.json(campaign);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch campaign" });
    }
  });

  // Create new campaign
  app.post("/api/campaigns", async (req, res) => {
    try {
      // Convert string date to Date object before validation
      const requestData = { ...req.body };
      if (requestData.endDate && typeof requestData.endDate === 'string') {
        requestData.endDate = new Date(requestData.endDate);
      }
      
      const campaignData = insertCampaignSchema.parse(requestData);
      const campaign = await storage.createCampaign(campaignData);
      res.status(201).json(campaign);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid campaign data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create campaign", error: error?.message || "Unknown error" });
    }
  });

  // Get fundings for a campaign
  app.get("/api/campaigns/:id/fundings", async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      const fundings = await storage.getFundingsByCampaign(campaignId);
      res.json(fundings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch fundings" });
    }
  });

  // Record a funding transaction
  app.post("/api/campaigns/:id/fund", async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      const fundingData = insertFundingSchema.parse({ ...req.body, campaignId });
      
      const funding = await storage.createFunding(fundingData);
      
      // Update campaign current amount
      const campaign = await storage.getCampaignById(campaignId);
      if (campaign) {
        const currentAmount = campaign.currentAmount || "0";
        const newAmount = (parseFloat(currentAmount) + parseFloat(fundingData.amount)).toString();
        await storage.updateCampaignAmount(campaignId, newAmount);
      }
      
      res.status(201).json(funding);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid funding data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to record funding" });
    }
  });

  // Upload image to Pinata IPFS
  app.post("/api/upload-image", async (req, res) => {
    try {
      const { imageData, filename } = req.body;
      
      if (!imageData || !filename) {
        return res.status(400).json({ message: "Image data and filename are required" });
      }

      // In a real implementation, this would upload to Pinata IPFS
      // For now, we'll simulate the upload and return a mock IPFS hash
      const mockIpfsHash = "Qm" + Math.random().toString(36).substring(2, 15);
      const ipfsUrl = `https://gateway.pinata.cloud/ipfs/${mockIpfsHash}`;
      
      res.json({ ipfsUrl, ipfsHash: mockIpfsHash });
    } catch (error) {
      res.status(500).json({ message: "Failed to upload image" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
