import { campaigns, fundings, type Campaign, type InsertCampaign, type Funding, type InsertFunding } from "@shared/schema";

export interface IStorage {
  // Campaign operations
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  getCampaigns(): Promise<Campaign[]>;
  getCampaignById(id: number): Promise<Campaign | undefined>;
  getCampaignByContractAddress(contractAddress: string): Promise<Campaign | undefined>;
  updateCampaignAmount(id: number, amount: string): Promise<void>;
  
  // Funding operations
  createFunding(funding: InsertFunding): Promise<Funding>;
  getFundingsByCampaign(campaignId: number): Promise<Funding[]>;
}

export class MemStorage implements IStorage {
  private campaigns: Map<number, Campaign> = new Map();
  private fundings: Map<number, Funding> = new Map();
  private campaignIdCounter = 1;
  private fundingIdCounter = 1;

  async createCampaign(insertCampaign: InsertCampaign): Promise<Campaign> {
    const id = this.campaignIdCounter++;
    const campaign: Campaign = {
      ...insertCampaign,
      id,
      currentAmount: "0",
      isActive: true,
      createdAt: new Date(),
    };
    this.campaigns.set(id, campaign);
    return campaign;
  }

  async getCampaigns(): Promise<Campaign[]> {
    return Array.from(this.campaigns.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getCampaignById(id: number): Promise<Campaign | undefined> {
    return this.campaigns.get(id);
  }

  async getCampaignByContractAddress(contractAddress: string): Promise<Campaign | undefined> {
    return Array.from(this.campaigns.values()).find(
      campaign => campaign.contractAddress === contractAddress
    );
  }

  async updateCampaignAmount(id: number, amount: string): Promise<void> {
    const campaign = this.campaigns.get(id);
    if (campaign) {
      campaign.currentAmount = amount;
      this.campaigns.set(id, campaign);
    }
  }

  async createFunding(insertFunding: InsertFunding): Promise<Funding> {
    const id = this.fundingIdCounter++;
    const funding: Funding = {
      ...insertFunding,
      id,
      createdAt: new Date(),
    };
    this.fundings.set(id, funding);
    return funding;
  }

  async getFundingsByCampaign(campaignId: number): Promise<Funding[]> {
    return Array.from(this.fundings.values())
      .filter(funding => funding.campaignId === campaignId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }
}

export const storage = new MemStorage();
